# @file: build_grader.sh
# @author: Mark Nguyen

g++ -o ../../bin/grader -std=c++11 -O2 -g *.cpp